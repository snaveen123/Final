package me.jysh.cinematic.exception;

public class AuditoriumNotFoundException extends RuntimeException {
    public AuditoriumNotFoundException(Long auditorium_id) {
    }
}
