package me.jysh.cinematic.configuration;

public class DevBootstrap {
}
