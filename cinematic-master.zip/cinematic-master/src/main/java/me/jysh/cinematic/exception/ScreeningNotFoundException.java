package me.jysh.cinematic.exception;

public class ScreeningNotFoundException extends RuntimeException {
}
