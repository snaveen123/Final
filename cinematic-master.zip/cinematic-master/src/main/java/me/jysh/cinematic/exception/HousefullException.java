package me.jysh.cinematic.exception;

public class HousefullException extends Throwable {
}
